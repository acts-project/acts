# Changelog

## v20200416

*   Mark the output operator `operator<<` for named tuples as
    potentially unused to suppress compile errors.
*   Enable the format targets only when the project is build directly
    and not when it is included via `add_submodule`.

## v20200330

*   First tagged version.
